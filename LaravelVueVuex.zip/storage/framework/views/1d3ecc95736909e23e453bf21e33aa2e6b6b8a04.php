
<?php $__env->startSection("center"); ?>
    <div class="w-full" id="profile-head">
    <div class="w-full">
            <profile v-bind:user_profile="<?php echo e($profile); ?>" v-bind:owned="<?php echo e(json_encode(auth()->user()->can('update', $profile))); ?>" v-bind:followable="<?php echo e(json_encode(auth()->user()->can('follow', $profile))); ?>" v-bind:visitor="<?php echo e(auth()->user()->id); ?>"
            v-bind:toastCount="<?php echo e($profile->user->toasts->count()); ?>"
            v-bind:followingCount="<?php echo e($profile->user->followings->count()); ?>"
            v-bind:followedCount="<?php echo e($profile->followers->count()); ?>"
            ></profile>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/profile.blade.php ENDPATH**/ ?>
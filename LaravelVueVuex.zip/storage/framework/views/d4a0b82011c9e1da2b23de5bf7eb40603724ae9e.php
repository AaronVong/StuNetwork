
<?php $__env->startSection("content"); ?>
<div class="auth-container relative w-full h-screen flex justify-center items-center px-2">
    <div class="w-full h-auto p-4 rounded-xl bg-white md:w-2/4 lg:w-3/6 xl:w-2/6">
        <?php echo $__env->yieldContent("auth-form"); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.root", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/layouts/auth.blade.php ENDPATH**/ ?>
@extends('layouts.auth')
@section('auth-form')
    <!-- Vue Verify Email Form Here -->
    <verify-email-form></verify-email-form>
@endsection
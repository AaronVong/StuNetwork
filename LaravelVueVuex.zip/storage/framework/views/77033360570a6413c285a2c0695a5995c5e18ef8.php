
<?php $__env->startSection('auth-form'); ?>
    <!-- Vue Verify Email Form Here -->
    <verify-email-form></verify-email-form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/auth/verifyemail.blade.php ENDPATH**/ ?>
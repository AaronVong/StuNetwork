
<?php $__env->startSection('auth-form'); ?>
    <!-- Vue Login Form Here -->
    <login-form v-bind:register_route="'<?php echo e(route('register')); ?>'" v-bind:password_route="'<?php echo e(route('password.request')); ?>'"></login-form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/auth/login.blade.php ENDPATH**/ ?>
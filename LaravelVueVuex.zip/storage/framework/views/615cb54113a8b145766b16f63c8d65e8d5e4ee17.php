
<?php $__env->startSection("content"); ?>
<div id="admin-layout" class="w-full h-full">
    <admin-nav></admin-nav>
    <div class="col-span-1 admin-content p-2 md:p-4">
        <h1 id="top" class="text-5xl capitalize text-center py-3 mb-3 text-gray-600 bg-gray-200">
            <span class="main-red">S</span>
            <span class="main-blue">T</span>
            <span class="main-red">U</span>
            <span class="text-lg text-gray-900">Network</span>
        </h1>
        <?php echo $__env->yieldContent("admin-content"); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.root", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
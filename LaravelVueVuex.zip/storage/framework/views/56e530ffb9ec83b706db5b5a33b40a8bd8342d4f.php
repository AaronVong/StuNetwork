
<?php $__env->startSection("admin-content"); ?>
<div id="admin-info" class="w-full mb-3 bg-indigo-500 text-gray-200">
    <h3 class="text-2xl p-3 text-center font-semibold">
        Thông tin tài khoản
    </h3>
    <user-detail :user="<?php echo e($user); ?>" :profile="<?php echo e($user->profile); ?>" :permissions="<?php echo e($user->getAllPermissions()); ?>" :user_permissions="<?php echo e($userPermissions); ?>"></user-detail>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/admin/user-detail.blade.php ENDPATH**/ ?>
<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Không tìm thấy thông tin phù hợp trong hệ thống.',
    'password' => 'Mật khẩu không chính xác.',
    'throttle' => 'Vượt quá số lần thử. Hãy thử lại sau :seconds giây.',

];

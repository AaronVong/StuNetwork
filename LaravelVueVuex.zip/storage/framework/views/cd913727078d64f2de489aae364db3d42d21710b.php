
<?php $__env->startSection('auth-form'); ?>
    <!-- Vue Regitser Form Here -->
    <register-form v-bind:login_route="'<?php echo e(route('login')); ?>'" v-bind:password_route="'<?php echo e(route('password.request')); ?>'"></register-form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/auth/register.blade.php ENDPATH**/ ?>
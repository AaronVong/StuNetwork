
<?php $__env->startSection("center"); ?>
<div class="w-full h-full">
   <div class="w-full border-b">
        <!-- Dynamic Header Title Here -->
        <h1 class="font-bold text-xl p-3">Trang chủ</h1>
   </div>
    <div class="w-full border-b">
        <div class="w-full p-3">
            <!-- Toast Form Here -->
            <toast-form></toast-form>
        </div>
    </div>
    <div class="w-full">
        <!-- Toast List Here -->
        <toast-list v-bind:owner="<?php echo e(auth()->user()->id); ?>" v-bind:guest="<?php echo e(auth()->user()->id); ?>" v-bind:toast_list="<?php echo e(json_encode($toasts)); ?>"></toast-list>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/home.blade.php ENDPATH**/ ?>
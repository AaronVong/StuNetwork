
<?php $__env->startSection("content"); ?>
    <div class="w-full h-full lg:container lg:mx-auto grid grid-cols-4 md:auto-cols-min divide-x divide-gray-200 overflow-hidden">
        <div class="relative flex w-full justify-center grid-cols-1">
            <div class="w-full">
            <!-- Web Main Navigator Here -->
               <?php echo $__env->make("client/components.mainnav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="relative col-span-3 xl:col-span-2">
            <!-- Web Contents Here -->
            <chat-app v-bind:user="<?php echo e(auth()->user()); ?>"></chat-app>
        </div>
        <div class="relative w-full justify-center md:gird-cols-1 hidden lg:flex">
            <div class="w-full p-3">
             <!-- Web Side Bar Here -->
               <search :user="<?php echo e(auth()->user()); ?>"></search>
               <chat-list v-bind:chat_list="<?php echo e(auth()->user()->followings); ?>"></chat-list>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.root", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/chat.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>STUNetWork</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <script type="text/javascript" src="https://kit.fontawesome.com/d210984464.js" crossorigin="anonymous"></script>
    </head>
    <body>
       <div id="app" class="w-full h-full">
            <?php echo $__env->yieldContent("content"); ?>
       </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/layouts/root.blade.php ENDPATH**/ ?>
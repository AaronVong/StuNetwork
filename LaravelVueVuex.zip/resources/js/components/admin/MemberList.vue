<template>
    <div class="w-full"></div>
</template>

<script>
export default {
    name: "MemberList",
    data() {
        return {
            page: 1,
            members: [],
        };
    },
    computed: {},
    methods: {},
    mounted() {},
};
</script>


<?php $__env->startSection("auth-form"); ?>
    <h1 class="text-4xl capitalize text-center py-2 text-gray-600">Khôi phục mật khẩu</h1>
    <forgot-password-form></forgot-password-form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.auth", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\LaravelVueVuex\resources\views/client/pages/auth/forgotpassword.blade.php ENDPATH**/ ?>